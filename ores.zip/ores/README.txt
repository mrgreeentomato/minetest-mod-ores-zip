this mod adds new ores, tools, food and other things.

no licence.

this optionally depends on chicken_block.

ask me to install it.

current version is 1.0.0.

to get help come to my desk.

made by mrtomato.
